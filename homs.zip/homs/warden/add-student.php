<?php
session_start();
error_reporting(0);
include('../includes/dbconn.php');

if(strlen($_SESSION['alogin'])==0) {   
    header('location:index.php');
} else {
    if(isset($_POST['add'])) {
        // Code for adding a single student
        $empid = $_POST['empcode'];
        $fname = $_POST['firstName'];
        $lname = $_POST['lastName'];   
        $email = $_POST['email']; 
        $password = md5($_POST['password']); 
        $gender = $_POST['gender']; 
        $dob = $_POST['dob']; 
        $department = $_POST['department']; 
        $address = $_POST['address']; 
        $city = $_POST['city']; 
        $country = $_POST['country']; 
        $mobileno = $_POST['mobileno']; 
        $status = 1;

        $sql = "INSERT INTO tblemployees(EmpId, FirstName, LastName, EmailId, Password, Gender, Dob, Department, Address, City, Country, Phonenumber, Status) VALUES(:empid, :fname, :lname, :email, :password, :gender, :dob, :department, :address, :city, :country, :mobileno, :status)";
        $query = $dbh->prepare($sql);
        $query->bindParam(':empid', $empid, PDO::PARAM_STR);
        $query->bindParam(':fname', $fname, PDO::PARAM_STR);
        $query->bindParam(':lname', $lname, PDO::PARAM_STR);
        $query->bindParam(':email', $email, PDO::PARAM_STR);
        $query->bindParam(':password', $password, PDO::PARAM_STR);
        $query->bindParam(':gender', $gender, PDO::PARAM_STR);
        $query->bindParam(':dob', $dob, PDO::PARAM_STR);
        $query->bindParam(':department', $department, PDO::PARAM_STR);
        $query->bindParam(':address', $address, PDO::PARAM_STR);
        $query->bindParam(':city', $city, PDO::PARAM_STR);
        $query->bindParam(':country', $country, PDO::PARAM_STR);
        $query->bindParam(':mobileno', $mobileno, PDO::PARAM_STR);
        $query->bindParam(':status', $status, PDO::PARAM_STR);
        $query->execute();
        $lastInsertId = $dbh->lastInsertId();
        if($lastInsertId) {
            $msg = "Record has been added Successfully";
        } else {
            $error = "ERROR";
        }
    }

    // Code for importing multiple students from CSV
    if(isset($_POST["submit"])) {
        if($_FILES['file']['name']) {
            $filename = explode(".", $_FILES['file']['name']);
            if($filename[1] == 'csv') {
                $handle = fopen($_FILES['file']['tmp_name'], "r");
                while($data = fgetcsv($handle)) {
                    $item1 = mysqli_real_escape_string($connect, $data[0]);  
                    $item2 = mysqli_real_escape_string($connect, $data[1]);
                    // You can modify this part to match your database structure
                    $query = "INSERT into tblemployees(EmpId, FirstName, LastName, EmailId) values('$item1','$item2')";
                    mysqli_query($connect, $query);
                }
                fclose($handle);
                echo "<script>alert('Import done');</script>";
            }
        }
    }
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Admin Panel - Student Management</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <!-- Add other CSS and scripts -->
</head>
<body>
    <div class="page-container">
        <!-- Sidebar and Header code -->

        <!-- Add Student Form -->
        <div class="col-12 mt-5">
            <?php if($error) { ?>
                <div class="alert alert-danger"><?php echo htmlentities($error); ?></div>
            <?php } else if($msg) { ?>
                <div class="alert alert-success"><?php echo htmlentities($msg); ?></div>
            <?php } ?>
            <div class="card">
                <form name="addemp" method="POST">
                    <div class="card-body">
                        <h4>Add Single Student</h4>
                        <!-- Form fields for single student -->
                        <div class="form-group">
                            <label for="empcode">Student ID</label>
                            <input class="form-control" name="empcode" type="text" required>
                        </div>
                        <div class="form-group">
                            <label for="firstName">First Name</label>
                            <input class="form-control" name="firstName" type="text" required>
                        </div>
                        <div class="form-group">
                            <label for="lastName">Last Name</label>
                            <input class="form-control" name="lastName" type="text" required>
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input class="form-control" name="email" type="email" required>
                        </div>
                        <!-- Add other input fields -->
                        <button class="btn btn-primary" name="add" type="submit">Add Student</button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Import CSV Form -->
        <div class="col-12 mt-5">
            <h4>Import Students from CSV</h4>
            <form method="post" enctype="multipart/form-data">
                <div align="center">  
                    <label>Select CSV File:</label>
                    <input type="file" name="file" />
                    <br />
                    <input type="submit" name="submit" value="Import" class="btn btn-info" />
                </div>
            </form>
        </div>
    </div>
    <!-- Footer and scripts -->
</body>
</html>

<?php } ?>
