<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>CA Panel - Student Leave</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="../assets/css/themify-icons.css">
    <link rel="stylesheet" href="../assets/css/metisMenu.css">
    <link rel="stylesheet" href="../assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="../assets/css/slicknav.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.18/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/typography.css">
    <link rel="stylesheet" href="../assets/css/default-css.css">
    <link rel="stylesheet" href="../assets/css/styles.css">
    <link rel="stylesheet" href="../assets/css/responsive.css">
    <script src="../assets/js/vendor/modernizr-2.8.3.min.js"></script>
    <style>
        .center {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            font-size: 25rem;
        }
        .green-tick {
            color: green;
        }
        .red-cross {
            color: red;
        }
    </style>
</head>

<body>
<div class="card-body">
    <div class="data-tables datatable-dark">
        <?php 
        include('../includes/dbconn.php');

        // Get the employee ID from the POST request
        $v = $_POST['number_index'];

        // Set the timezone
        date_default_timezone_set('Asia/Kolkata');

        // Get the current date and time
        $currentDateTime = new DateTime();
        $currentDate = $currentDateTime->format('Y-m-d'); 
        $currentTime = $currentDateTime->format('H:i:s');

        // Fetch employee data
        $sql = "SELECT * FROM tblemployees WHERE EmpId = :v";
        $stmt = $dbh->prepare($sql);
        $stmt->bindParam(':v', $v);
        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_OBJ);

        $check = false;

        if ($stmt->rowCount() > 0) {
            foreach ($results as $result) {
                $emp_id = $result->id;

                // Fetch leave data
                $sql_1 = "SELECT * FROM tblleaves WHERE empid = :emp_id AND :currentDate BETWEEN FromDate AND ToDate";
                $stmt1 = $dbh->prepare($sql_1);
                $stmt1->bindParam(':emp_id', $emp_id);
                $stmt1->bindParam(':currentDate', $currentDate);
                $stmt1->execute();
                $leaveResults = $stmt1->fetchAll(PDO::FETCH_OBJ);

                if ($stmt1->rowCount() > 0) {
                    foreach ($leaveResults as $leave) {
                        $leave_id = $leave->id; // Unique identifier for the leave record
                        $fromdate = $leave->FromDate;
                        $todate = $leave->ToDate;
                        $outtime = $leave->outtime;
                        $intime = $leave->intime;
                        $status = $leave->Status;
                        $castatus = $leave->castatus;
                        $hodstatus = $leave->hodstatus;
                        $vpstatus = $leave->vpstatus;
                        $scanouttime = $leave->scanouttime;
                        $scanintime = $leave->scanintime;
                        
                        // Convert dates to timestamps for comparison
                        $fromdateTimestamp = strtotime($fromdate);
                        $todateTimestamp = strtotime($todate);
                        $currentDateTimestamp = strtotime($currentDate);
                        $currentTimeTimestamp = strtotime($currentTime);
                        $outTimestamp = strtotime($outtime);
                        $inTimestamp = strtotime($intime);

                        if ($currentDateTimestamp < $todateTimestamp && $currentDateTimestamp > $fromdateTimestamp ) {
                            $check = ($status == 1 && ($castatus == 1 || $castatus == 4) 
                                    && ($hodstatus == 1 || $hodstatus == 4) 
                                    && ($vpstatus == 1 || $vpstatus == 4)); // Valid pass
                            
                            if ($check) {
                                // Update scanouttime or scanintime based on the current time
                                if ($scanouttime == NULL) {
                                    $update_sql = "UPDATE tblleaves SET scanouttime = :currentTime WHERE id = :leave_id";
                                } else {
                                    $update_sql = "UPDATE tblleaves SET scanintime = :currentTime WHERE id = :leave_id";
                                }

                                $update_stmt = $dbh->prepare($update_sql);
                                $update_stmt->bindParam(':currentTime', $currentTime);
                                $update_stmt->bindParam(':leave_id', $leave_id);

                                // Execute the update query and check for success
                                if ($update_stmt->execute()) {
                                    echo "Update successful.<br>";
                                } else {
                                    echo "Update failed.<br>";
                                }

                                break; // No need to check further leaves
                            }
                        }
                        
                        
                         if($currentDateTimestamp < $todateTimestamp && $currentDateTimestamp == $fromdateTimestamp){
                            if ($currentTimeTimestamp >= $outTimestamp) {
                                $check = ($status == 1 && ($castatus == 1 || $castatus == 4) 
                                        && ($hodstatus == 1 || $hodstatus == 4) 
                                        && ($vpstatus == 1 || $vpstatus == 4)); // Valid pass

                                if ($check) {
                                    // Update scanouttime or scanintime based on the current time
                                    if ($scanouttime == NULL) {
                                        $update_sql = "UPDATE tblleaves SET scanouttime = :currentTime WHERE id = :leave_id";
                                    } else {
                                        $update_sql = "UPDATE tblleaves SET scanintime = :currentTime WHERE id = :leave_id";
                                    }

                                    $update_stmt = $dbh->prepare($update_sql);
                                    $update_stmt->bindParam(':currentTime', $currentTime);
                                    $update_stmt->bindParam(':leave_id', $leave_id);

                                    // Execute the update query and check for success
                                    if ($update_stmt->execute()) {
                                        echo "Update successful.<br>";
                                    } else {
                                        echo "Update failed.<br>";
                                    }

                                    break; // No need to check further leaves
                                }
                            }
                        }
                        
                         if($currentDateTimestamp == $todateTimestamp && $currentDateTimestamp > $fromdateTimestamp){
                            if ($currentTimeTimestamp <= $inTimestamp) {
                                $check = ($status == 1 && ($castatus == 1 || $castatus == 4) 
                                        && ($hodstatus == 1 || $hodstatus == 4) 
                                        && ($vpstatus == 1 || $vpstatus == 4)); // Valid pass

                                if ($check) {
                                    // Update scanouttime or scanintime based on the current time
                                    if ($scanouttime == NULL) {
                                        $update_sql = "UPDATE tblleaves SET scanouttime = :currentTime WHERE id = :leave_id";
                                    } else {
                                        $update_sql = "UPDATE tblleaves SET scanintime = :currentTime WHERE id = :leave_id";
                                    }

                                    $update_stmt = $dbh->prepare($update_sql);
                                    $update_stmt->bindParam(':currentTime', $currentTime);
                                    $update_stmt->bindParam(':leave_id', $leave_id);

                                    // Execute the update query and check for success
                                    if ($update_stmt->execute()) {
                                        echo "Update successful.<br>";
                                    } else {
                                        echo "Update failed.<br>";
                                    }

                                    break; // No need to check further leaves
                                }
                            }
                        }
                        
                        if($currentDateTimestamp == $todateTimestamp && $currentDateTimestamp == $fromdateTimestamp){
                            if ($currentTimeTimestamp >= $outTimestamp && $currentTimeTimestamp <= $inTimestamp) {
                                $check = ($status == 1 && ($castatus == 1 || $castatus == 4) 
                                        && ($hodstatus == 1 || $hodstatus == 4) 
                                        && ($vpstatus == 1 || $vpstatus == 4)); // Valid pass

                                if ($check) {
                                    // Update scanouttime or scanintime based on the current time
                                    if ($scanouttime == NULL) {
                                        $update_sql = "UPDATE tblleaves SET scanouttime = :currentTime WHERE id = :leave_id";
                                    } else {
                                        $update_sql = "UPDATE tblleaves SET scanintime = :currentTime WHERE id = :leave_id";
                                    }

                                    $update_stmt = $dbh->prepare($update_sql);
                                    $update_stmt->bindParam(':currentTime', $currentTime);
                                    $update_stmt->bindParam(':leave_id', $leave_id);

                                    // Execute the update query and check for success
                                    if ($update_stmt->execute()) {
                                        echo "Update successful.<br>";
                                    } else {
                                        echo "Update failed.<br>";
                                    }

                                    break; // No need to check further leaves
                                }
                            }
                        }
                    }
                }

                if ($check) {
                    break;
                }
            }
        }

        // Display result based on the check
        if ($check) {
            echo '<div class="center green-tick">&#10004;</div>'; // Green tick
            echo '<script>
                    setTimeout(function() {
                        window.location.href = "scan.php";
                    }, 3000); // 3 seconds delay
                  </script>';
        } else {
            echo '<div class="center red-cross">&#10008;</div>'; // Red cross
            echo '<script>
                    setTimeout(function() {
                        window.location.href = "scan.php";
                    }, 3000); // 3 seconds delay
                  </script>';
        }
        ?>
    </div>
</div>
</body>
</html>
