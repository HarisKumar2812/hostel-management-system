<!DOCTYPE html>
<html>
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html5-qrcode/2.3.4/html5-qrcode.min.js" integrity="sha512-k/KAe4Yff9EUdYI5/IAHlwUswqeipP+Cp5qnrsUjTPCgl51La2/JhyyjNciztD7mWNKLSXci48m7cctATKfLlQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
</head>
<body class="body_app">
<nav class="navbar navbar-light bg-light mb-3">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">
            HOMS SECURITY SCAN PAGE
        </a>
    </div>
</nav>
<style>
    main {
        display: flex;
        justify-content: center;
        align-items: center;
        border-radius: 20px;
    }
    #reader {
        width: 600px;
        border-radius: 30px;
    }
    #result {
        text-align: center;
        font-size: 1.5rem;
    }
</style>
<main>
    <div id="reader" class="rounded"></div>
    <div id="result"></div>
</main>
<script>
    const scanner = new Html5QrcodeScanner('reader', {
        qrbox: {
            width: 250,
            height: 250,
        },
        fps: 20,
    });

    scanner.render(success, error);

    function success(result) {
        let today = new Date().toISOString().slice(0, 10);
        const date_obj = new Date();
        time = new Date().toLocaleTimeString();
        document.getElementById('result').innerHTML = `
            <div class="card" style="width: 18rem;">
                <img src="barcode-scan.gif" class="card-img-top" alt="...">
                <div class="card-body">
                    <form action="v.php" method="post" id="scan">
                        <p style="font-size: 14px;" class="card-text">Bar Code Read Successfully : <span class="badge bg-primary">${result}</span></p>
                        <p style="font-size: 14px;" class="card-text">Date : <span class="badge bg-primary">${today}</span></p>
                        <p style="font-size: 14px;" class="card-text">Capture Time : <span class="badge bg-primary">${time}</span></p>
                        <input type="hidden" name="number_index" value="${result}" id="result">
                        <input type="hidden" name="time_val" value="${time}" id="capture_time">
                        <input type="hidden" name="date_val" value="${today}" id="capture_date">
                    </form>
                </div>
            </div>
        `;
        scanner.clear();
        document.getElementById('reader').remove();
        // Submit the form automatically
        document.getElementById('scan').submit();
    }

    function error(err) {
        console.error(err);
    }
</script>
</body>
</html>
