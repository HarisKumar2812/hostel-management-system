<link rel="stylesheet" href="../assets/css/styles.css">

<?php 
    $dept=$_SESSION['dept'];
    include 'dbconn.php';
    $hodisread=0;
    $sql = "SELECT * from tblleaves  where hodIsread=:hodisread and tblleaves.dept = '$dept' and tblleaves.hodstatus != 4 and tblleaves.castatus = 1" ;
    $query = $dbh -> prepare($sql);
    $query->bindParam(':hodisread',$hodisread,PDO::PARAM_STR);
    $query->execute();
    $results=$query->fetchAll(PDO::FETCH_OBJ);
    $unreadcount=$query->rowCount();

?>
    
    <li class="dropdown">
        <i class="ti-bell dropdown-toggle" data-toggle="dropdown">
            <span><?php echo htmlentities($unreadcount);?></span>
            </i>
            <div class="dropdown-menu bell-notify-box notify-box">
            <span class="notify-title">You have <?php echo htmlentities($unreadcount);?> <b>unread</b> notifihodtions!</span>

            <div class="notify-list">
            <?php 
                $hodisread=0;
                $dept=$_SESSION['dept'];
                include 'dbconn.php';
                $sql = "SELECT tblleaves.id as lid, tblleaves.*, tblemployees.* 
                FROM tblleaves 
                JOIN tblemployees ON tblleaves.empid = tblemployees.id 
                WHERE tblleaves.hodIsread=:hodisread 
                    AND tblleaves.dept = '$dept' 
                    AND tblleaves.hodstatus != 4 
                    AND tblleaves.castatus = 1";
                // $sql = "SELECT * from tblleaves  where hodIsread=:hodisread and tblleaves.hod = '$hod'" ;
                $query = $dbh -> prepare($sql);
                $query->bindParam(':hodisread',$hodisread,PDO::PARAM_STR);
    //             $sql = "SELECT *
    //            FROM tblleaves JOIN tblemployees ON tblleaves.empid = tblemployees.id where tblleaves.caIsread=:caisread and
    //            tblleaves.ca = '$ca' and tblleaves.castatus != 4
    //    -- WHERE tblleaves.dept = $dept1
    //    ";
                $query->execute();
                $results=$query->fetchAll(PDO::FETCH_OBJ);
                if($query->rowCount() > 0)
                {
                foreach($results as $result)
                {               ?>  
                    
                     
                     <a href="studentpassdetails.php?leaveid=<?php echo htmlentities($result->lid);?>" class="notify-item">
                       <div class="notify-thumb"><i class="ti-comments-smiley btn-info"></i></div>
                       <div class="notify-text">
                       <p><b><?php echo htmlentities($result->FirstName." ".$result->LastName);?>
                                            <br />(<?php echo htmlentities($result->EmpId);?>)
                                            </b> has recently applied for a leave.</p>
                            <span>at <?php echo htmlentities($result->PostingDate);?></b</span>
                        </div>
                      </a>
                                        
                      <?php }} ?> 
                     </div>
                            
                     
                     
                      </div>
                      
     </li>

     