<?php
$servername = $_SERVER['SERVER_NAME'];
echo "Your Hostname is: " . $servername;
?>
