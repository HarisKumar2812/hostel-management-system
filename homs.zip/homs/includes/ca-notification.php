<link rel="stylesheet" href="../assets/css/styles.css">

<?php 
    $ca=$_SESSION['ca'];
    include 'dbconn.php';
    $caisread=0;
    $sql = "SELECT * from tblleaves  where caIsread=:caisread and tblleaves.ca = '$ca' and tblleaves.castatus != 4 and tblleaves.Status = 1" ;
    $query = $dbh -> prepare($sql);
    $query->bindParam(':caisread',$caisread,PDO::PARAM_STR);
    $query->execute();
    $results=$query->fetchAll(PDO::FETCH_OBJ);
    $unreadcount=$query->rowCount();

?>
    
    <li class="dropdown">
        <i class="ti-bell dropdown-toggle" data-toggle="dropdown">
            <span><?php echo htmlentities($unreadcount);?></span>
            </i>
            <div class="dropdown-menu bell-notify-box notify-box">
            <span class="notify-title">You have <?php echo htmlentities($unreadcount);?> <b>unread</b> notifications!</span>

            <div class="notify-list">
            <?php 
                $caisread=0;
                $ca=$_SESSION['ca'];
                include 'dbconn.php';
                $sql = "SELECT tblleaves.id as lid, tblleaves.*, tblemployees.* 
                FROM tblleaves 
                JOIN tblemployees ON tblleaves.empid = tblemployees.id 
                WHERE tblleaves.caIsread=:caisread 
                    AND tblleaves.ca = '$ca' 
                    AND tblleaves.castatus != 4 
                    AND tblleaves.Status = 1";
                // $sql = "SELECT * from tblleaves  where caIsread=:caisread and tblleaves.ca = '$ca'" ;
                $query = $dbh -> prepare($sql);
                $query->bindParam(':caisread',$caisread,PDO::PARAM_STR);
    //             $sql = "SELECT *
    //            FROM tblleaves JOIN tblemployees ON tblleaves.empid = tblemployees.id where tblleaves.caIsread=:caisread and
    //            tblleaves.ca = '$ca' and tblleaves.castatus != 4
    //    -- WHERE tblleaves.dept = $dept1
    //    ";
                $query->execute();
                $results=$query->fetchAll(PDO::FETCH_OBJ);
                if($query->rowCount() > 0)
                {
                foreach($results as $result)
                {               ?>  
                    
                     <a href="studentpassdetails.php?leaveid=<?php echo htmlentities($result->lid);?>" class="notify-item">
                       <div class="notify-thumb"><i class="ti-comments-smiley btn-info"></i></div>
                       <div class="notify-text">
                       <p><b><?php echo htmlentities($result->FirstName." ".$result->LastName);?>
                                            <br />(<?php echo htmlentities($result->EmpId);?>)
                                            </b> has recently applied for a leave.</p>
                            <span>at <?php echo htmlentities($result->PostingDate);?></b</span>
                        </div>
                      </a>
                                        
                      <?php }} ?> 
                     </div>
                            
                     
                     
                      </div>
                      
     </li>

     