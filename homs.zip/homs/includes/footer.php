<footer>
        <div class="footer-area">
                <p>© <?php echo date("Y");?> | Hostel Outpass Management System | Developed By <a href="https://reshist.me" target="_blank">Reshi S T</a></p>
        </div>
</footer>